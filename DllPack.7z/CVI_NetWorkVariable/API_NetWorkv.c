#include "toolbox.h"
#include "API_NetWorkV.h"
#include <cvirte.h>


NENGTONG_API int __stdcall API_CNVCreateSubscriber(const char * networkVariablePathName,
        CNVDataCallback dataCallback,
        CNVStatusCallback statusCallback,
        void * callbackData,
        int waitTime,
        intptr_t reserved,
        CNVSubscriber * subscriber)
{
    int Ret = 0 ;
    if(strlen(networkVariablePathName) == 0)
    {
        return RET_ERROR_INVALID_NETWORK_VARIABLE_NAME;
    }

    if(NULL == dataCallback)
    {
        return RET_ERROR_INVALID_CALLBACK_FUNCTION_ADDR;
    }

    if(waitTime < 0)
    {
        return RET_ERROR_INVALID_POINTER;
    }

    Ret = CNVCreateSubscriber(networkVariablePathName, dataCallback, statusCallback, callbackData,
                              waitTime, reserved, subscriber);

    return Ret;
}

NENGTONG_API int __stdcall  API_CNVCreateBufferedWriter(const char * networkVariablePathName,
        CNVDataTransferredCallback dataTransferredCallback,
        CNVStatusCallback statusCallback,
        void * callbackData,
        int clientBufferMaxItems,
        int waitTime,
        intptr_t reserved,
        CNVBufferedWriter * bufferedWriter)
{
    int Ret = 0 ;

    if(strlen(networkVariablePathName) == 0)
    {
        return RET_ERROR_INVALID_NETWORK_VARIABLE_NAME;
    }

//     if(NULL == dataTransferredCallback)
//     {
//         return RET_ERROR_INVALID_CALLBACK_FUNCTION_ADDR;
//     }

    if(waitTime < 0)
    {
        return RET_ERROR_INVALID_POINTER;
    }

    Ret = CNVCreateBufferedWriter(networkVariablePathName,
                                  dataTransferredCallback,
                                  statusCallback,
                                  callbackData,
                                  clientBufferMaxItems,
                                  waitTime,
                                  reserved,
                                  bufferedWriter);
    return Ret;
}

NENGTONG_API int __stdcall API_NetworkVariablePopup(char * pBuffer)
{
    int Ret = 0  ;

    if(NULL == pBuffer)
    {
        return RET_ERROR_INVALID_BUFF;
    }

    Ret = NetworkVariablePopup(pBuffer);
    return Ret;
}

NENGTONG_API int __stdcall API_CNVGetDataType(CNVData data, CNVDataType * type, unsigned int * pNumDimensions)
{
    int Ret = 0  ;

    if(NULL == data)
    {
        return RET_ERROR_INVALID_BUFF;
    }

    if(NULL == type)
    {
        return RET_ERROR_INVALID_POINTER;
    }

    if(NULL == pNumDimensions)
    {
        return RET_ERROR_INVALID_POINTER;
    }

    Ret = CNVGetDataType(data, type, pNumDimensions);

    return Ret;
}

NENGTONG_API int __stdcall API_CNVGetScalarDataValue(CNVData data, CNVDataType type, void * pValue)
{
    int Ret = 0  ;

    if(NULL == data)
    {
        return RET_ERROR_INVALID_BUFF;
    }

    if(NULL == type)
    {
        return RET_ERROR_INVALID_BUFF;
    }

    if(NULL == pValue)
    {
        return RET_ERROR_INVALID_POINTER;
    }

    Ret = CNVGetScalarDataValue(data, type, pValue);
    return Ret ;
}



NENGTONG_API int __stdcall API_CNVDisposeData(CNVData data)
{
    int Ret = 0  ;

    if(NULL == data)
    {
        return RET_ERROR_INVALID_BUFF;
    }

    Ret = CNVDisposeData(data);
    return Ret;
}

NENGTONG_API int __stdcall  API_CNVDisposeHandle(void  *pHandle)
{
    int Ret = 0  ;

    if(NULL == pHandle)
    {
        return RET_ERROR_INVALID_BUFF;
    }

    Ret = CNVDispose(pHandle);
    return Ret;
}

NENGTONG_API void __stdcall  API_CNVFinish()
{
    CNVFinish();
}

NENGTONG_API const char* __stdcall  API_CNVGetErrorDescription(int errorCode)
{
    return CNVGetErrorDescription(errorCode);
}



NENGTONG_API int __stdcall API_CNVCreateScalarDataValue(CNVData * pData, CNVDataType type,  double dValue)
{
    int Ret = 0  ;

    if(NULL == pData)
    {
        return RET_ERROR_INVALID_BUFF;
    }

    if(NULL == type)
    {
        return RET_ERROR_INVALID_STRUCT;
    }
    Ret = CNVCreateScalarDataValue(pData , type , dValue);

    return Ret;
}

NENGTONG_API int __stdcall  API_CNVPutDataInBuffer(CNVBufferedWriter bufferedWriter, CNVData data,
        int bufferWaitTime)
{
    int Ret = 0  ;

    if(NULL == bufferedWriter)
    {
        return RET_ERROR_INVALID_BUFF;
    }

    if(NULL == data)
    {
        return RET_ERROR_INVALID_STRUCT;
    }

    Ret = CNVPutDataInBuffer(bufferedWriter , data , bufferWaitTime);

    return Ret;
}

NENGTONG_API int __stdcall API_CNVBrowse(CNVBrowser browser, const char * location)
{
    return CNVBrowse(browser, location);
}

NENGTONG_API int __stdcall API_CNVBrowseNextItem(CNVBrowser browser, char ** item, int * leaf,
        CNVBrowseType * browseType, CNVData * typeData)
{
    return CNVBrowseNextItem(browser, item, leaf, browseType, typeData);
}

NENGTONG_API int __stdcall API_CNVCreateBrowser(CNVBrowser * browser)
{
    return CNVCreateBrowser(browser);
}

NENGTONG_API int __stdcall API_CNVDisposeBrowser(CNVBrowser browser)
{
    return CNVDisposeBrowser(browser);
}

NENGTONG_API int __stdcall API_CNVFreeMemory(void * pointer)
{
    CNVFreeMemory(pointer);
    return 0;
}
