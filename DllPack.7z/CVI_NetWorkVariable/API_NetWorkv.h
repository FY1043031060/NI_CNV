//==============================================================================
//
// Title:       API_NetWorkv.h
// Purpose:     A short description of the interface.
//
// Created on:  2017/12/14 at 19:53:54 by wwl.
// Copyright:   . All Rights Reserved.
//
//==============================================================================


#ifndef __API_NetWorkv_H__
#define __API_NetWorkv_H__

#ifdef __cplusplus
extern "C" {
#endif

#ifndef NENGTONG_API_IMPORT
#define NENGTONG_API __declspec(dllexport)
#else
#define NENGTONG_API __declspec(dllimport)
#endif

#include "cvinetv.h"
#include "cvidef.h"

enum RET_T {RET_REG_SUCCESS = 0, RET_ERROR_INVALID_BUFF = -1, RET_ERROR_INVALID_POINTER = -2, RET_ERROR_INVALID_STRUCT = -3, RET_ERROR_INVALID_WAITTIME = -4,
            RET_ERROR_INVALID_NETWORK_VARIABLE_NAME = -5, RET_ERROR_INVALID_CALLBACK_FUNCTION_ADDR = -6

           };



NENGTONG_API int __stdcall  API_CNVCreateSubscriber(const char * networkVariablePathName,
        CNVDataCallback dataCallback,
        CNVStatusCallback statusCallback,
        void * callbackData,
        int waitTime,
        intptr_t reserved,
        CNVSubscriber * subscriber);

NENGTONG_API int __stdcall API_CNVCreateBufferedWriter(const char * networkVariablePathName,
        CNVDataTransferredCallback dataTransferredCallback,
        CNVStatusCallback statusCallback,
        void * callbackData,
        int clientBufferMaxItems,
        int waitTime,
        intptr_t reserved,
        CNVBufferedWriter * bufferedWriter);

NENGTONG_API int __stdcall API_NetworkVariablePopup(char *pBuffer);


NENGTONG_API int __stdcall API_CNVGetDataType(CNVData data, CNVDataType * type, unsigned int * pNumDimensions);

NENGTONG_API int __stdcall API_CNVGetScalarDataValue(CNVData data, CNVDataType type, void * pValue) ;

NENGTONG_API int __stdcall API_CNVCreateScalarDataValue(CNVData * data, CNVDataType type, double dValue);

NENGTONG_API int __stdcall API_CNVPutDataInBuffer(CNVBufferedWriter bufferedWriter, CNVData data, int bufferWaitTime);

NENGTONG_API int __stdcall API_CNVDisposeData(CNVData data);

NENGTONG_API int __stdcall API_CNVDisposeHandle(void * pHandle);

NENGTONG_API void __stdcall API_CNVFinish();

NENGTONG_API const char* __stdcall  API_CNVGetErrorDescription(int errorCode);

NENGTONG_API int __stdcall API_CNVBrowse(CNVBrowser browser, const char * location);

NENGTONG_API int __stdcall API_CNVBrowseNextItem(CNVBrowser browser, char ** item, int * leaf,
        CNVBrowseType * browseType, CNVData * typeData);

NENGTONG_API int __stdcall API_CNVCreateBrowser(CNVBrowser * browser);

NENGTONG_API int __stdcall API_CNVDisposeBrowser(CNVBrowser browser);

NENGTONG_API int __stdcall API_CNVFreeMemory(void * pointer);

#ifdef __cplusplus
}
#endif

#endif  /* ndef __API_NetWorkv_H__ */
